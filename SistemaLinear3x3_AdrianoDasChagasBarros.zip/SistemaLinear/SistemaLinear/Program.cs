﻿using System;

class Program
{
    static void Main()
    {
        bool continuar = true;

        while (continuar)
        {
            // Determina a quantidade de coeficientes 
            double[,] coeficientes = new double[3, 3];
            // Determina a quantidade de constantes
            double[] constantes = new double[3];

            // Leitura dos coeficientes
            Console.WriteLine("Digite os coeficientes do sistema:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write($"a[{i + 1},{j + 1}]: ");
                    coeficientes[i, j] = Convert.ToDouble(Console.ReadLine());
                }
            }

            // Leitura dos termos constantes
            Console.WriteLine("\nDigite os termos constantes:");
            for (int i = 0; i < 3; i++)
            {
                Console.Write($"b[{i + 1}]: ");
                constantes[i] = Convert.ToDouble(Console.ReadLine());
            }

            // Calcula os determinantes
            double determinanteA = CalcularDeterminante(coeficientes);
            double determinanteX = CalcularDeterminante(SubstituirColuna(coeficientes, constantes, 0));
            double determinanteY = CalcularDeterminante(SubstituirColuna(coeficientes, constantes, 1));
            double determinanteZ = CalcularDeterminante(SubstituirColuna(coeficientes, constantes, 2));

            // Verifica se todos os coeficientes são zero
            bool todosZeros = true;
            foreach (double coeficiente in coeficientes)
            {
                if (coeficiente != 0)
                {
                    todosZeros = false;
                    break;
                }
            }

            // Classificação do sistema
            if (determinanteA != 0)
            {
                Console.WriteLine($"\nDeterminante de A: {determinanteA}, Determinante de X: {determinanteX}, Determinante de Y: {determinanteY}, Determinante de Z: {determinanteZ}");
                Console.WriteLine($"Solução: x = {determinanteX / determinanteA}, y = {determinanteY / determinanteA}, z = {determinanteZ / determinanteA}");
                Console.WriteLine("O sistema é possível e determinado.");
            }
            else if (todosZeros)
            {
                Console.WriteLine($"\nDeterminante de A: {determinanteA}, Determinante de X: {determinanteX}, Determinante de Y: {determinanteY}, Determinante de Z: {determinanteZ}");
                Console.WriteLine("O sistema é impossível.");

            }
            else
            {
                Console.WriteLine($"\nDeterminante de A: {determinanteA}, Determinante de X: {determinanteX}, Determinante de Y: {determinanteY}, Determinante de Z: {determinanteZ}");
                Console.WriteLine("O sistema é possível e indeterminado.");
                
            }



            // Pergunta se o usuário deseja continuar
            Console.Write("\nDeseja executar mais algum cálculo? (S/N): ");
            char resposta = Console.ReadLine().ToUpper()[0];
            continuar = (resposta == 'S');

            // Limpa o console se o usuário quiser continuar
            if (continuar)
            {
                Console.Clear();
            }
        }

        // Fecha a aplicação
        Environment.Exit(0);
    }

    // Função para calcular o determinante de uma matriz 3x3
    static double CalcularDeterminante(double[,] matriz)
    {
        return matriz[0, 0] * matriz[1, 1] * matriz[2, 2] +
               matriz[0, 1] * matriz[1, 2] * matriz[2, 0] +
               matriz[0, 2] * matriz[1, 0] * matriz[2, 1] -
               matriz[0, 2] * matriz[1, 1] * matriz[2, 0] -
               matriz[0, 1] * matriz[1, 0] * matriz[2, 2] -
               matriz[0, 0] * matriz[1, 2] * matriz[2, 1];
    }

    // Função para substituir uma coluna de uma matriz pelos valores de um vetor
    static double[,] SubstituirColuna(double[,] matriz, double[] vetor, int coluna)
    {
        double[,] novaMatriz = (double[,])matriz.Clone();
        for (int i = 0; i < 3; i++)
        {
            novaMatriz[i, coluna] = vetor[i];
        }
        return novaMatriz;
    }
}
